# RecordAndPlay

How to Recording Audio file and Play it.

https://iosdevcenters.blogspot.com/2016/05/audio-recording-and-playing-in-swift.html

RecordAndPlay in Swift.
